#pragma once

const int STONE_PERCENT = 20, COIN_PERCENT = 30, COIN_UP = 1;